<?php
$footval = "chat_smile";
require_once ('system/func.php');
require_once ('system/dbc.php');
require_once 'system/foot/foot.php';
?>
<html>
    <head>
        <title>smiles</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
    <center>
        <div><b>-Список смайлов-</b></div>
        <div>XD<img src='/img/smile/smile_1.png?272.0' width='22px' alt='XD'></div>
        <div>:-)<img src='/img/smile/smile_2.png?272.0' width='22px' alt=':-)'></div>
        <div>:(<img src='/img/smile/smile_3.png?272.0' width='22px' alt=':('></div>
        <div>:-(<img src='/img/smile/smile_3.png?272.0' width='22px' alt=':-('></div>
        <div>;)<img src='/img/smile/smile_4.png?272.0' width='22px' alt=';)'></div>
        <div>;-)<img src='/img/smile/smile_4.png?272.0' width='22px' alt=';-)'></div>
        <div>:[<img src='/img/smile/0.png?272.0' width='22px' alt=':['></div>
        <div>:-*<img src='/img/smile/1.png?272.0' width='22px' alt=':-*'></div>
        <div>:-0<img src='/img/smile/2.png?272.0' width='22px' alt=':-0'></div>
        <div>:-D<img src='/img/smile/3.png?272.0' width='22px' alt=':-D'></div>
        <div>:!<img src='/img/smile/4.png?272.0' width='22px' alt=':!'></div>
        <div>:_)<img src='/img/smile/5.png?272.0' width='22px' alt=':_)'></div>
        <div>8[*<img src='/img/smile/6.png?272.0' width='22px' alt='8[*'></div>
        <div>:#<img src='/img/smile/7.png?272.0' width='22px' alt=':#'></div>
        <div>)))<img src='/img/smile/8.png?272.0' width='22px' alt=')))'></div>
        <div>:-|<img src='/img/smile/9.png?272.0' width='22px' alt=':-|'></div>
        <div>3|<img src='/img/smile/10.png?272.0' width='22px' alt='3|'></div>
        <div>;|<img src='/img/smile/11.png?272.0' width='22px' alt=';|'></div>
        <div>*dntknw*<img src='/img/smile/12.png?272.0' width='22px' alt='*dntknw*'></div>
        <div>*ermm*<img src='/img/smile/13.png?272.0' width='22px' alt='*ermm*'></div>
        <div>*hm*<img src='/img/smile/14.png?272.0' width='22px' alt='*hm*'></div>
        <div>:o)<img src='/img/smile/15.png?272.0' width='22px' alt=':o)'></div>
        <div>8|<img src='/img/smile/16.png?272.0' width='22px' alt='8|'></div>
        <div>*nirvana*<img src='/img/smile/17.png?272.0' width='22px' alt='*nirvana*'></div>
        <div>*zawtoroj*<img src='/img/smile/18.png?272.0' width='22px' alt='*zawtoroj*'></div>
        <div>*LICK*<img src='/img/smile/19.png?272.0' width='22px' alt='*LICK*'></div>
        <div>*happy*<img src='/img/smile/20.png?272.0' width='22px' alt='*happy*'></div>
        <div>*yes*<img src='/img/smile/21.png?272.0' width='22px' alt='*yes*'></div>
        <div>:-s<img src='/img/smile/22.png?272.0' width='22px' alt=':-s'></div>
        <div>=/<img src='/img/smile/23.png?272.0' width='22px' alt='=/'></div>
        <div>:@<img src='/img/smile/24.png?272.0' width='22px' alt=':@'></div>
        <div>*secret*<img src='/img/smile/25.png?272.0' width='22px' alt='*secret*'></div>
        <div>*botan*<img src='/img/smile/26.png?272.0' width='22px' alt='*botan*'></div>
        <div>*ninja*<img src='/img/smile/27.png?272.0' width='22px' alt='*ninja*'></div>
        <div>*bravo*<img src='/img/smile/28.png?272.0' width='22px' alt='*bravo*'></div>
        <div>[F]<img src='/img/smile/29.png?272.0' width='22px' alt='[F]'></div>
        <div>[L]<img src='/img/smile/30.png?272.0' width='22px' alt='[L]'></div>
        <div>:пиво:<img src='/img/smile/pivo.png?272.0' width='28px' alt=':пиво:'></div>
        <div>:100:<img src='img/smiles/100.png?272.0' width='22px' alt=':100:'></div>
        <div>:101:<img src='img/smiles/101.png?272.0' width='22px' alt=':101:'></div>
        <div>:102:<img src='img/smiles/102.png?272.0' width='22px' alt=':102:'></div>
        <div>:103:<img src='img/smiles/103.png?272.0' width='22px' alt=':103:'></div>
        <div>:104:<img src='img/smiles/104.png?272.0' width='22px' alt=':104:'></div>
        <div>:105:<img src='img/smiles/105.png?272.0' width='22px' alt=':105:'></div>
        <div>:106:<img src='img/smiles/106.png?272.0' width='22px' alt=':106:'></div>
        <div>:107:<img src='img/smiles/107.png?272.0' width='22px' alt=':107:'></div>
        <div>:108:<img src='img/smiles/108.png?272.0' width='22px' alt=':108:'></div>
        <div>:109:<img src='img/smiles/109.png?272.0' width='22px' alt=':109:'></div>
        <div>:110:<img src='img/smiles/110.png?272.0' width='22px' alt=':110:'></div>
        <div>:111:<img src='img/smiles/111.png?272.0' width='22px' alt=':111:'></div>
        <div>:112:<img src='img/smiles/112.png?272.0' width='22px' alt=':112:'></div>
        <div>:113:<img src='img/smiles/113.png?272.0' width='22px' alt=':113:'></div>
        <div>:114:<img src='img/smiles/114.png?272.0' width='22px' alt=':114:'></div>
        <div>:115:<img src='img/smiles/115.png?272.0' width='22px' alt=':115:'></div>
        <div>:116:<img src='img/smiles/116.png?272.0' width='22px' alt=':116:'></div>
        <div>:117:<img src='img/smiles/117.png?272.0' width='22px' alt=':117:'></div>
        <div>:118:<img src='img/smiles/118.png?272.0' width='22px' alt=':118:'></div>
        <div>:119:<img src='img/smiles/119.png?272.0' width='22px' alt=':119:'></div>
        <div>:120:<img src='img/smiles/120.png?272.0' width='22px' alt=':120:'></div>
        <div>:121:<img src='img/smiles/121.png?272.0' width='22px' alt=':121:'></div>
        <div>:122:<img src='img/smiles/122.png?272.0' width='22px' alt=':122:'></div>
        <div>:123:<img src='img/smiles/123.png?272.0' width='22px' alt=':123:'></div>
        <div>:124:<img src='img/smiles/124.png?272.0' width='22px' alt=':124:'></div>
        <div>:125:<img src='img/smiles/125.png?272.0' width='22px' alt=':125:'></div>
        <div>:126:<img src='img/smiles/126.png?272.0' width='22px' alt=':126:'></div>
        <div>:127:<img src='img/smiles/127.png?272.0' width='22px' alt=':127:'></div>
        <div>:128:<img src='img/smiles/128.png?272.0' width='22px' alt=':128:'></div>
        <div>:129:<img src='img/smiles/129.png?272.0' width='22px' alt=':129:'></div>
        <div>:130:<img src='img/smiles/130.png?272.0' width='22px' alt=':130:'></div>
        <div>:131:<img src='img/smiles/131.png?272.0' width='22px' alt=':131:'></div>
        <div>:132:<img src='img/smiles/132.png?272.0' width='22px' alt=':132:'></div>
        <div>:133:<img src='img/smiles/133.png?272.0' width='22px' alt=':133:'></div>
        <div>:134:<img src='img/smiles/134.png?272.0' width='22px' alt=':134:'></div>
        <div>:135:<img src='img/smiles/135.png?272.0' width='22px' alt=':135:'></div>
        <div>:136:<img src='img/smiles/136.png?272.0' width='22px' alt=':136:'></div>
        <div>:137:<img src='img/smiles/137.png?272.0' width='22px' alt=':137:'></div>
        <div>:138:<img src='img/smiles/138.png?272.0' width='22px' alt=':138:'></div>
        <div>:139:<img src='img/smiles/139.png?272.0' width='22px' alt=':139:'></div>
        <div>:140:<img src='img/smiles/140.png?272.0' width='22px' alt=':140:'></div>
        <div>:141:<img src='img/smiles/141.png?272.0' width='22px' alt=':141:'></div>
        <div>:142:<img src='img/smiles/142.png?272.0' width='22px' alt=':142:'></div>
        <div>:143:<img src='img/smiles/143.png?272.0' width='22px' alt=':143:'></div>
        <div>:144:<img src='img/smiles/144.png?272.0' width='22px' alt=':144:'></div>
        <div>:145:<img src='img/smiles/145.png?272.0' width='22px' alt=':145:'></div>
        <div>:146:<img src='img/smiles/146.png?272.0' width='22px' alt=':146:'></div>
        <div>:147:<img src='img/smiles/147.png?272.0' width='22px' alt=':147:'></div>
        <div>:148:<img src='img/smiles/148.png?272.0' width='22px' alt=':148:'></div>
        <div>:149:<img src='img/smiles/149.png?272.0' width='22px' alt=':149:'></div>
        <div>:150:<img src='img/smiles/150.png?272.0' width='22px' alt=':150:'></div>
        <div>:151:<img src='img/smiles/151.png?272.0' width='22px' alt=':151:'></div>
        <div>:152:<img src='img/smiles/152.png?272.0' width='22px' alt=':152:'></div>
        <div>:153:<img src='img/smiles/153.png?272.0' width='22px' alt=':153:'></div>
        <div>:154:<img src='img/smiles/154.png?272.0' width='22px' alt=':154:'></div>
        <div>:155:<img src='img/smiles/155.png?272.0' width='22px' alt=':155:'></div>
        <div>:156:<img src='img/smiles/156.png?272.0' width='22px' alt=':156:'></div>
        <div>:157:<img src='img/smiles/157.png?272.0' width='22px' alt=':157:'></div>
        <div>:158:<img src='img/smiles/158.png?272.0' width='22px' alt=':158:'></div>
        <div>:159:<img src='img/smiles/159.png?272.0' width='22px' alt=':159:'></div>
        <div>:160:<img src='img/smiles/160.png?272.0' width='22px' alt=':160:'></div>
        <div>:161:<img src='img/smiles/161.png?272.0' width='22px' alt=':161:'></div>
        <div>:162:<img src='img/smiles/162.png?272.0' width='22px' alt=':162:'></div>
        <div>:163:<img src='img/smiles/163.png?272.0' width='22px' alt=':163:'></div>
        <div>:164:<img src='img/smiles/164.png?272.0' width='22px' alt=':164:'></div>
        <div>:165:<img src='img/smiles/165.png?272.0' width='22px' alt=':165:'></div>
        <div>:166:<img src='img/smiles/166.png?272.0' width='22px' alt=':166:'></div>
        <div>:167:<img src='img/smiles/167.png?272.0' width='22px' alt=':167:'></div>
        <div>:168:<img src='img/smiles/168.png?272.0' width='22px' alt=':168:'></div>
        <div>:169:<img src='img/smiles/169.png?272.0' width='22px' alt=':169:'></div>
        <div>:170:<img src='img/smiles/170.png?272.0' width='22px' alt=':170:'></div>
        <div>:171:<img src='img/smiles/171.png?272.0' width='22px' alt=':171:'></div>
        <div>:172:<img src='img/smiles/172.png?272.0' width='22px' alt=':172:'></div>
        <div>:173:<img src='img/smiles/173.png?272.0' width='22px' alt=':173:'></div>
        <div>:174:<img src='img/smiles/174.png?272.0' width='22px' alt=':174:'></div>
        <div>:175:<img src='img/smiles/175.png?272.0' width='22px' alt=':175:'></div>
        <div>:176:<img src='img/smiles/176.png?272.0' width='22px' alt=':176:'></div>
        <div>:177:<img src='img/smiles/177.png?272.0' width='22px' alt=':177:'></div>
        <div>:178:<img src='img/smiles/178.png?272.0' width='22px' alt=':178:'></div>
        <div>:179:<img src='img/smiles/179.png?272.0' width='22px' alt=':179:'></div>
        <div>:180:<img src='img/smiles/180.png?272.0' width='22px' alt=':180:'></div>
        <div>:181:<img src='img/smiles/181.png?272.0' width='22px' alt=':181:'></div>
        <div>:182:<img src='img/smiles/182.png?272.0' width='22px' alt=':182:'></div>
        <div>:183:<img src='img/smiles/183.png?272.0' width='22px' alt=':183:'></div>
        <div>:184:<img src='img/smiles/184.png?272.0' width='22px' alt=':184:'></div>
        <div>:185:<img src='img/smiles/185.png?272.0' width='22px' alt=':185:'></div>
        <div>:186:<img src='img/smiles/186.png?272.0' width='22px' alt=':186:'></div>
        <div>:187:<img src='img/smiles/187.png?272.0' width='22px' alt=':187:'></div>
        <div>:188:<img src='img/smiles/188.png?272.0' width='22px' alt=':188:'></div>
        <div>:189:<img src='img/smiles/189.png?272.0' width='22px' alt=':189:'></div>
        <div>:190:<img src='img/smiles/190.png?272.0' width='22px' alt=':190:'></div>
        <div>:191:<img src='img/smiles/191.png?272.0' width='22px' alt=':191:'></div>
        <div>:192:<img src='img/smiles/192.png?272.0' width='22px' alt=':192:'></div>
        <div>:193:<img src='img/smiles/193.png?272.0' width='22px' alt=':193:'></div>
        <div>:194:<img src='img/smiles/194.png?272.0' width='22px' alt=':194:'></div>
        <div>:195:<img src='img/smiles/195.png?272.0' width='22px' alt=':195:'></div>
        <div>:196:<img src='img/smiles/196.png?272.0' width='22px' alt=':196:'></div>
        <div>:197:<img src='img/smiles/197.png?272.0' width='22px' alt=':197:'></div>
        <div>:198:<img src='img/smiles/198.png?272.0' width='22px' alt=':198:'></div>
        <div>:199:<img src='img/smiles/199.png?272.0' width='22px' alt=':199:'></div>
        <div>:200:<img src='img/smiles/200.png?272.0' width='22px' alt=':200:'></div>
        <div>:201:<img src='img/smiles/201.png?272.0' width='22px' alt=':201:'></div>
        <div>:202:<img src='img/smiles/202.png?272.0' width='22px' alt=':202:'></div>
        <div>:203:<img src='img/smiles/203.jpg?272.0' width='22px' alt=':203:'></div>
        <div>:204:<img src='img/smiles/204.png?272.0' width='22px' alt=':204:'></div>
        <div>:205:<img src='img/smiles/205.png?272.0' width='22px' alt=':205:'></div>
        <div>:206:<img src='img/smiles/206.png?272.0' width='22px' alt=':206:'></div>
        <div>:207:<img src='img/smiles/207.png?272.0' width='22px' alt=':207:'></div>
        <div>:208:<img src='img/smiles/208.png?272.0' width='22px' alt=':208:'></div>
        <div>:209:<img src='img/smiles/209.png?272.0' width='22px' alt=':209:'></div>
        <div>:210:<img src='img/smiles/210.png?272.0' width='22px' alt=':210:'></div>
        <div>:211:<img src='img/smiles/211.png?272.0' width='22px' alt=':211:'></div>
        <div>:212:<img src='img/smiles/212.png?272.0' width='22px' alt=':212:'></div>
        <div>:213:<img src='img/smiles/213.png?272.0' width='22px' alt=':213:'></div>
        <div>:214:<img src='img/smiles/214.png?272.0' width='22px' alt=':214:'></div>
        <div>:215:<img src='img/smiles/215.png?272.0' width='22px' alt=':215:'></div>
        <div>:216:<img src='img/smiles/216.png?272.0' width='22px' alt=':216:'></div>
        <div>:217:<img src='img/smiles/217.png?272.0' width='22px' alt=':217:'></div>
        <div>:218:<img src='img/smiles/218.png?272.0' width='22px' alt=':218:'></div>
        <div>:219:<img src='img/smiles/219.png?272.0' width='22px' alt=':219:'></div>
        <div>:220:<img src='img/smiles/220.png?272.0' width='22px' alt=':220:'></div>
    </CENTER>
</body>
</html>