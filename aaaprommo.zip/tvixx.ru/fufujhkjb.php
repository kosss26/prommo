<?php phpinfo(); ?>

