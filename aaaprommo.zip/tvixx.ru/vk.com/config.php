<?php
class Config_vk{
	public $key="dc665c8978a8894475ce0af9aaa28903f03800e183a232aeceda7867d07cc2cb52ee114e3e0ae9764196c";
	public $back="81224e5f";
	public $privat="DSAFqirhh32qiuyrhu23h2";
	
}
?>