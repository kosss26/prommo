<?php

$roboniz = <<< NOCH
            </td>
              </tr>
            </table>
          </div>
        </div>

      </td>
    </tr>
   </tbody>
  </table>
  <table style="border: 1px solid black; width: 800px; background-color: white; margin-top: 2px;" cellpadding="3" cellspacing="3" border="0">
    <tr>
      <td><!-- SpyLOG -->
<script src="http://tools.spylog.ru/counter_cv.js" id="spylog_code" type="text/javascript" counter="1088814" part="" track_links="ext" page_level="0">
</script>
<noscript>
<a href="http://u10888.14.spylog.com/cnt?cid=1088814&f=3&p=0" target="_blank">
<img src="http://u10888.14.spylog.com/cnt?cid=1088814&p=0" alt="SpyLOG" border="0" width="88" height="31"></a>
</noscript>
<!--/ SpyLOG -->
<!--Raskrytka.Ru counter--><a href="http://www.raskrytka.ru" target="_blank"><img src="http://counter.web-marketolog.ru/counter/?mode=b3-1" width=88 height=31 border=0 alt="раскрутка сайта, поисковая оптимизация"></a><!--/Raskrytka.Ru counter-->
<!--www.seozavr.ru--><a href="http://www.seozavr.ru/index.php?id=12332"><img src="http://www.seozavr.ru/img/seo_zavr88-31.gif" alt="www.seozavr.ru - автоматическое размещение статей с прямыми ссылками" border="0" /></a><!--/www.seozavr.ru-->
<a href="http://yandex.ru/cy?base=0&amp;host=xnomer.ru"><img src="http://www.yandex.ru/cycounter?xnomer.ru" width="88" height="31" alt="Яндекс цитирования" border="0" /></a>
<!-- begin of Top100 logo -->
<a href="http://top100.rambler.ru/top100/"><img src="http://top100-images.rambler.ru/top100/banner-88x31-rambler-black2.gif" alt="Rambler's Top100" width="88" height="31" border="0" /></a>
<!-- end of Top100 logo -->
</td>
    </tr>
  </table>
</div></body>
</html>
NOCH;
$footval='robo';
include 'system/foot/foot.php';
?>

