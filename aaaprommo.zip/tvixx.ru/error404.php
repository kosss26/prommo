<?php
require_once ('system/func.php');
require_once ('system/header.php');
?>

<body>
<center>
    
    <div style="color: red;">
        <h1>Нет Данных</h1>
    </div>
пожалуйста обратитесь в <a>службу поддержки</a></p>
    </center>
</body>
<?php
$footval='error404';
require_once ('system/foot/foot.php');
?>
