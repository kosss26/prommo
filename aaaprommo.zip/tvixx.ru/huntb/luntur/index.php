<?php
require_once '../../system/func.php';
?>

<div>
    <center>
        <div>
            <b>-Турниры полной луны-</b>
        </div>
    </center>
    <hr class="hr_02">
    <center>
        <div style="padding-bottom: 3px;">
            Регистрация <b>20:45</b>, старт <b>21:00</b>
        </div>
    </center>
    <div class="clanturblock">1</div>
    <div class="clanturblock">2</div>
    <div class="clanturblock">3</div>
    <div class="clanturblock">4</div>
    <div class="clanturblock">5</div>
    <center>
        <div style="padding-bottom: 3px;">
            Завершенные :
        </div>
    </center>
    <div class="clanturblock">1</div>
    <div class="clanturblock">2</div>
    <div class="clanturblock">3</div>
    <div class="clanturblock">4</div>
    <div class="clanturblock">5</div>
</div>

<?php

$footval = "clantur_huntb";
require_once ('../../system/foot/foot.php');
?>